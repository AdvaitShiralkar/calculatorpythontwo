Release 0.0.4:
    -Fixed issue in setup.py
